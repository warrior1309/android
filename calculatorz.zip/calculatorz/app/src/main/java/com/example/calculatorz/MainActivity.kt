package com.example.calculatorz

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import javax.script.ScriptEngine
import javax.script.ScriptEngineManager
import javax.script.ScriptException

class MainActivity : AppCompatActivity() {

    //Number Button
    lateinit var mBtn0: Button
    lateinit var mBtn1: Button
    lateinit var mBtn2: Button
    lateinit var mBtn3: Button
    lateinit var mBtn4: Button
    lateinit var mBtn5: Button
    lateinit var mBtn6: Button
    lateinit var mBtn7: Button
    lateinit var mBtn8: Button
    lateinit var mBtn9: Button
    lateinit var mBtnd_oo: Button  //   mBtn9cb    button_00


    //Symbol Button
    lateinit var mBtnDivision: Button    //  mBtnDivision           button_divide
    lateinit var mBtnMultiplication: Button // mBtnMultiplication           button_multiply
    lateinit var mBtnAddition: Button     // mBtnAddition             button_plus
    lateinit var mBtnSubstract: Button    //  mBtnSubstract         button_minus
    lateinit var mBtnperc: Button   //  mBtnperc    btnper
    lateinit var mBtnEqual: Button   //   mBtnEqual             button_equals

    lateinit var mBtnDot: Button      //  mBtnDot            button_dot
//    lateinit var result_tv: Button

    //Clear Button
    lateinit var mBtnClear: Button       //  button_c        mBtnClear
    lateinit var mBtnClearAll: Button      //  button_ac       mBtnClearAll

    //Show Digit EditText
    lateinit var mEdtshow_1: EditText  //  solution_tv  mEdtshow_1
    lateinit var mEdtSHow: EditText    //  result_tv    mEdtSHow

    var check = 0






    var operator:Char = ' '

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()
        mBtn0 = findViewById(R.id.button_zero)
        mBtn1 = findViewById(R.id.button_1)
        mBtn2 = findViewById(R.id.button_2)
        mBtn3 = findViewById(R.id.button_3)
        mBtn4 = findViewById(R.id.button_4)
        mBtn5 = findViewById(R.id.button_5)
        mBtn6 = findViewById(R.id.button_6)
        mBtn7 = findViewById(R.id.button_7)
        mBtn8 = findViewById(R.id.button_8)
        mBtn9 = findViewById(R.id.button_9)
        mBtnperc = findViewById(R.id.btnper)
        mBtnd_oo = findViewById(R.id.button_oo)

        mBtnAddition = findViewById(R.id.button_plus)
        mBtnMultiplication = findViewById(R.id.button_multiply)
        mBtnDivision = findViewById(R.id.button_divide)
        mBtnSubstract = findViewById(R.id.button_minus)

        mBtnEqual = findViewById(R.id.button_equals)

        mBtnDot = findViewById(R.id.button_dot)

        mBtnClear = findViewById(R.id.button_c)
        mBtnClearAll = findViewById(R.id.button_ac)

        mEdtSHow = findViewById(R.id.result_tv)
        mEdtshow_1 = findViewById(R.id.solution_tv)



        mEdtshow_1.movementMethod = ScrollingMovementMethod()
        mEdtshow_1.setActivated(true)
        mEdtshow_1.setPressed(true)

        var text:String

        mBtn1.setOnClickListener{
            text = mEdtshow_1.text.toString() + "1"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn2.setOnClickListener{
            text = mEdtshow_1.text.toString() + "2"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn3.setOnClickListener{
            text = mEdtshow_1.text.toString() + "3"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn4.setOnClickListener{
            text = mEdtshow_1.text.toString() + "4"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn5.setOnClickListener{
            text = mEdtshow_1.text.toString() + "5"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn6.setOnClickListener{
            text = mEdtshow_1.text.toString() + "6"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn7.setOnClickListener{
            text = mEdtshow_1.text.toString() + "7"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn8.setOnClickListener{
            text = mEdtshow_1.text.toString() + "8"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn9.setOnClickListener{
            text = mEdtshow_1.text.toString() + "9"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtn0.setOnClickListener{
            text = mEdtshow_1.text.toString() + "0"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtnd_oo.setOnClickListener{
            text = mEdtshow_1.text.toString() + "00"
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtnDot.setOnClickListener{
            text = mEdtshow_1.text.toString() + "."
            mEdtshow_1.setText(text)
            mEdtSHow(text)
        }
        mBtnAddition.setOnClickListener{
            text = mEdtshow_1.text.toString() + "+"
            mEdtshow_1.setText(text)
            check = check+1
        }
        mBtnSubstract.setOnClickListener{
            text = mEdtshow_1.text.toString() + "-"
            mEdtshow_1.setText(text)
            check = check+1
        }
        mBtnDivision.setOnClickListener{
            text = mEdtshow_1.text.toString() + "/"
            mEdtshow_1.setText(text)
            check = check+1
        }
        mBtnMultiplication.setOnClickListener{
            text = mEdtshow_1.text.toString() + "*"
            mEdtshow_1.setText(text)
            check = check+1
        }
        mBtnperc.setOnClickListener{
            text = mEdtshow_1.text.toString() + "%"
            mEdtshow_1.setText(text)
            check = check+1
        }
        mBtnEqual.setOnClickListener{
            text = mEdtSHow.text.toString()
            mEdtshow_1.setText(text)
            mEdtSHow.setText(null)
        }
        mBtnClearAll.setOnClickListener{
            mEdtshow_1.setText(null)
            mEdtSHow.setText(null)
        }
        mBtnClear.setOnClickListener{
            var close :String? = null
            if(mEdtshow_1.text.length>0){
                val stringBuilder: StringBuilder = java.lang.StringBuilder(mEdtshow_1.text)
                val find = mEdtshow_1.text.toString()
                val find2 = find.last()
                if (find2.equals('+')||find2.equals('-')||find2.equals('*')||find2.equals('/')||find2.equals('%')){
                    check = check-1
                }
                stringBuilder.deleteCharAt(mEdtshow_1.text.length-1)
                close = stringBuilder.toString()
                mEdtshow_1.setText(close)
                mEdtSHow(close)
            }
        }
    }



    private fun mEdtSHow(text: String) {
        val engine: ScriptEngine = ScriptEngineManager().getEngineByName("rhino")
        try {
            val result: Any = engine.eval(text)
            var mainr = result.toString()
            if (check ==0){
                mEdtSHow.setText(null)
            }
            else{
                mEdtSHow.setText(mainr)
            }
        }
        catch (e : ScriptException)
        {
            Log.d("Tag","Error")
        }
    }



}


